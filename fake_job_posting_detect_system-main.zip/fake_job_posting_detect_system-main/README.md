# fake_job_posting_detect_system
https://fake-job-detect-system.herokuapp.com/
